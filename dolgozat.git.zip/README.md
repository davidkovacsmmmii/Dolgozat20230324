"# Dolgozat_2023.03.24" Készitete: Kovács Dávid"
